(function(){
const BL=window.BL,$=(s,r=document)=>r.querySelector(s),P=new URLSearchParams(location.search);
const sec=id=>BL.sections.find(s=>s.id===id);
const load=src=>new Promise(r=>{const e=document.createElement('script');e.src=src;e.onload=e.onerror=r;document.head.append(e)});
const topics=async id=>{if(!BL.topics[id])await load('data/topics/'+id+'.js');return BL.topics[id]||[]};
const LV=[['base','База','Главные идеи простыми словами'],['school','Школьный уровень','Материал по программе'],['deep','Углубление ЕМН','Детали для профильного уровня']];
const pl=n=>n%10==1&&n%100!=11?'тема':([2,3,4].includes(n%10)&&![12,13,14].includes(n%100)?'темы':'тем');
const dots=t=>'<span class="dots">'+LV.map((l,i)=>`<i class="l${i+1}${t.levels&&t.levels[l[0]]?' on':''}" title="${l[1]}"></i>`).join('')+'</span>';
const card=(s,i)=>`<a class="card" href="section.html?s=${s.id}"><span class="no">${BL.sections.indexOf(s)+1}</span><h3>${s.title}</h3><p>${s.desc}</p><span class="meta" data-n="${s.id}"></span></a>`;
const crumbs=a=>'<nav class="crumbs" aria-label="Хлебные крошки">'+a.map((x,i)=>(i?'<span>›</span>':'')+(x[0]?`<a href="${x[0]}">${x[1]}</a>`:x[1])).join('')+'</nav>';
const leaf='<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#3d6a50" stroke-width="1.8" stroke-linecap="round"><path d="M5 19C5 9 11 4 20 4c0 9-5 15-15 15zM5 19l8-8"/></svg>';
function shell(page,html){
 const nav=[['index.html','Главная','home'],['sections.html','Разделы','sections']];
 document.body.innerHTML=`<header class="top"><div class="wrap nav"><a class="logo" href="index.html">${leaf}BioLearn</a><button class="burger" aria-label="Меню">☰</button><nav class="links">${nav.map(n=>`<a href="${n[0]}"${page===n[2]?' class="on"':''}>${n[1]}</a>`).join('')}</nav></div></header><main class="wrap">${html}</main><footer><div class="wrap">BioLearn — бесплатная биология для школьников Казахстана</div></footer>`;
 $('.burger').onclick=()=>$('.links').classList.toggle('open');
}
function counts(){document.querySelectorAll('[data-n]').forEach(async e=>{const n=(await topics(e.dataset.n)).length;e.textContent=n?n+' '+pl(n):'Скоро'})}
const nf=()=>shell('sections',`<div class="empty" style="margin-top:40px"><h2 style="margin-top:0">Страница не найдена</h2><a class="btn" href="sections.html">К разделам</a></div>`);
const pages={
home(){shell('home',`<section class="hero"><div><h1>Вся биология школьной программы в 14 разделах</h1><p>Без деления на классы: каждая тема лежит в одном месте и раскрывается от базы до углубления.</p><a class="btn" href="sections.html">Открыть разделы</a></div><div class="stack">${LV.map((l,i)=>`<div class="l${i+1}">${l[1]}<small>${l[2]}</small></div>`).join('')}</div></section><h2>Разделы</h2><div class="grid">${BL.sections.slice(0,6).map(card).join('')}</div><p style="margin-top:28px"><a class="btn" href="sections.html">Все 14 разделов</a></p>`);document.title='BioLearn — биология для школьников Казахстана';counts()},
sections(){shell('sections',`${crumbs([['index.html','Главная'],[0,'Разделы']])}<h1>Разделы биологии</h1><p class="sub">Материал 7–11 классов ЕМН, собранный по смыслу.</p><div class="grid">${BL.sections.map(card).join('')}</div>`);document.title='Разделы — BioLearn';counts()},
async section(){const s=sec(P.get('s'));if(!s)return nf();const i=BL.sections.indexOf(s),l=await topics(s.id);document.title=s.title+' — BioLearn';
 shell('sections',`${crumbs([['index.html','Главная'],['sections.html','Разделы'],[0,s.title]])}<div class="shead"><span class="no">${i+1}</span><div><h1>${s.title}</h1><p>${s.desc}</p></div></div><div class="path">${LV.map((x,k)=>`<div class="l${k+1}">${x[1]}<small>${x[2]}</small></div>`).join('')}</div><h2>Темы раздела</h2>${l.length?`<div class="list">${l.map(t=>`<a class="rc" href="topic.html?s=${s.id}&t=${t.id}"><div><h3>${t.title}</h3><p>${t.summary||''}</p></div>${dots(t)}</a>`).join('')}</div>`:'<div class="empty">Темы этого раздела скоро появятся.</div>'}`)},
async topic(){const s=sec(P.get('s')),l=s?await topics(s.id):[],i=l.findIndex(t=>t.id===P.get('t')),t=l[i];if(!t)return nf();document.title=t.title+' — BioLearn';
 const lv=t.levels||{},first=Math.max(0,LV.findIndex(x=>lv[x[0]]));
 const pn=(x,d)=>x?`<a class="card ${d}" href="topic.html?s=${s.id}&t=${x.id}"><small>${d=='p'?'Предыдущая тема':'Следующая тема'}</small><b>${x.title}</b></a>`:`<a class="card ${d}" href="section.html?s=${s.id}"><small>Назад</small><b>К разделу</b></a>`;
 shell('sections',`${crumbs([['index.html','Главная'],['sections.html','Разделы'],['section.html?s='+s.id,s.title],[0,t.title]])}<div class="tgrid"><article><h1>${t.title}</h1><p class="sub">${t.summary||''}</p><div class="tabs">${LV.map((x,k)=>`<button data-k="${k}" class="${k==first?'on':''}${lv[x[0]]?'':' off'}">${x[1]}</button>`).join('')}</div>${LV.map((x,k)=>`<div class="lvl" data-k="${k}"${k==first?'':' hidden'}>${lv[x[0]]||'<div class="empty">Этот уровень скоро появится.</div>'}</div>`).join('')}${(t.figures||[]).map(f=>`<figure>${f.svg}<figcaption>${f.cap||''}</figcaption></figure>`).join('')}<div class="pn">${pn(l[i-1],'p')}${pn(l[i+1],'n')}</div></article><aside>${t.terms?`<div class="box"><h3>Ключевые термины</h3><dl>${t.terms.map(x=>`<dt>${x[0]}</dt><dd>${x[1]}</dd>`).join('')}</dl></div>`:''}${t.remember?`<div class="box tip"><h3>Важно запомнить</h3><p>${t.remember}</p></div>`:''}</aside></div>`);
 document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tabs button,.lvl').forEach(e=>{const on=e.dataset.k==b.dataset.k;if(e.tagName=='BUTTON')e.classList.toggle('on',on);else e.hidden=!on})})}
};
pages[document.body.dataset.page]();
})();
