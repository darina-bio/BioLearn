# BioLearn
Статический сайт для GitHub Pages (Settings → Pages → ветка main, папка root).

- Дизайн: assets/css/style.css
- Шаблоны страниц и навигация: assets/js/app.js
- Разделы: data/sections.js
- Темы: data/topics/<id раздела>.js — добавьте объект в массив, и тема появится сама.
Для нового раздела с темами создайте data/topics/<id>.js с `BL.topics.<id>=[...]`.
Локально: `python3 -m http.server` в папке проекта.
